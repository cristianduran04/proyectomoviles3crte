import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.parcialmoviles.MainActivity
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {

    private lateinit var scenario: ActivityScenario<MainActivity>

    @Before
    fun setUp() {
        // Inicializa el escenario de la actividad
        scenario = ActivityScenario.launch(MainActivity::class.java)
    }

    @Test
    fun testActivityLaunch() {
        // Verifica que la actividad se haya lanzado correctamente
        scenario.onActivity { activity ->
            assertNotNull(activity)
        }
    }

    @Test
    fun testButtonClick() {
        // Realiza clic en un botón y verifica que se realice una acción esperada
        onView(withId(R.id.myButton)).perform(click())

        // Agrega aquí tus aserciones adicionales según la acción realizada después de hacer clic en el botón
    }

    @After
    fun tearDown() {
        // Finaliza el escenario de la actividad después de cada prueba
        scenario.close()
    }
}
