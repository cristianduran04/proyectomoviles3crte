import android.content.Context

data class Anuncio(val imagenResId: Int)


